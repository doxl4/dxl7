import os,sys,time
while True:
  os.system("curl https://sheesh.rip/http --http2 --user-agent nigger -o http.txt")
  time.sleep(600)
